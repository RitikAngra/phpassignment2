$(document).ready(function () {
  if (window.location.pathname.includes("createlisting.php")) {
    var urlParams = new URLSearchParams(window.location.search);
    var listingId = urlParams.get("listingid");
    if (listingId) {
      $.ajax({
        type: "GET",
        url: "getlisting.php" + "?listingId=" + listingId,
        dataType: "json",
        success: function (listing) {
          if (listing) {
            $("<input>")
              .attr({
                type: "hidden",
                name: "listing_id",
                value: listing.listing_id,
              })
              .prependTo("form#createlisting-form");
            $("form#createlisting-form :input").each(function () {
              var input = $(this);
              var field = input.attr("name");
              if (listing[field]) input.val(listing[field]);
            });
          }
        },
      });
    }
  } else if (
    window.location.pathname.includes("index.php") ||
    window.location.pathname.includes("listing.php")
  ) {
    $.ajax({
      url: "getlisting.php",
      dataType: "json",
      success: function (response) {
        setTimeout(() => {
          if (response) {
            var { listings, loggedIn } = response;
            var listingGrid = $(".listings-grid");
            if (listingGrid) {
              listingGrid = listingGrid[0];
              if (listings.length) {
                if (window.location.pathname.includes("index.php")) {
                  listings = listings.slice(0, 6);
                }
                listingGrid.innerHTML = listings
                  .map((r) => {
                    let actions = "";
                    if (
                      !window.location.pathname.includes("index.php") &&
                      loggedIn
                    ) {
                      actions = `
                    <div class="card-badge grey" style="top:50px;z-index:1" onclick="window.location.href='createlisting.php?listingid=${r.listing_id}'">
                        <img height="25" width="20" src="./assets/icons/pencil.svg" alt="pencil">
                      </div>
                      <div class="card-badge grey" style="top:100px;z-index:1" onclick="this.firstElementChild.submit()">
                        <form action="deletelisting.php" method="POST" style="display:none;">
                            <input name="listingid" value="${r.listing_id}" />
                        </form>
                        <img height="25" width="20" src="./assets/icons/trash.svg" alt="trash">
                      </div>
                       `;
                    }
                    return `
                    <div class="w-dyn-item">
                                <div>
                                  <a href="#listing" class="card-wrap w-inline-block">
                                  <div class="card-badge ${
                                    r.type === "Rent" ? "green" : "orange"
                                  }">For ${r.type}</div>${actions}
                                  <img src="${
                                    r.listing_image
                                  }" loading="lazy" alt="${
                      r.location
                    }" class="card-image">
                                        <div class="card-text-wrap">
                                            <div class="text-tiny-caps text-neutral-2">${
                                              r.category
                                            }</div>
                                            <div class="card-title">${
                                              r.location
                                            }</div>
                                            <div class="card-title">$${
                                              r.price
                                            }${
                      r.type === "Rent"
                        ? "<sub class='text-tiny-caps text-neutral-2'> / Monthly</sub>"
                        : ""
                    }</div>
                                            <div class="listing-card-info-grid">
                                                <div class="listing-card-pricing-wrap"><img src="./assets/icons/bed.svg" loading="lazy" width="24" alt="" class="listing-card-info-icon">
                                                    <div class="listing-card-info-text space-right">${
                                                      r.beds
                                                    }</div>
                                                    <div class="listing-card-info-text">beds</div>
                                                </div>
                                                <div class="listing-card-pricing-wrap"><img src="./assets/icons/bath.svg" loading="lazy" width="24" alt="" class="listing-card-info-icon">
                                                    <div class="listing-card-info-text space-right">${
                                                      r.bathrooms
                                                    }</div>
                                                    <div class="listing-card-info-text">bathrooms</div>
                                                </div>
                                                <div class="listing-card-pricing-wrap"><img src="./assets/icons/door.svg" loading="lazy" width="24" alt="" class="listing-card-info-icon">
                                                    <div class="listing-card-info-text space-right">${
                                                      r.rooms
                                                    }</div>
                                                    <div class="listing-card-info-text">rooms</div>
                                                </div>
                                            </div>
                                        </div>
                                    </a>
                              </div>
                            </div>`;
                  })
                  .join("");
                $(".view-all-button-wrap").css("display", "flex");
              } else {
                listingGrid.style.textAlign = "center";
                listingGrid.style.gridTemplateColumns = "3fr";
                listingGrid.innerHTML = `<div style="font-size:1.25rem" class='button-text'>No listing found</div>
              <a style="margin:0 auto;" href="createlisting.php"><button class="header-top-btn">Add Listing</button></a>
              `;
              }
            }
          }
        }, 1500);
      },
    });
  }

  if ($("form")) $("form").submit(globalFormSubmit);
});

function globalFormSubmit(event) {
  if ($(this).attr("id") == "createlisting-form") {
    return;
  }
  event.preventDefault();
  var formAction = $(this).attr("action");
  var formMethod = $(this).attr("method");
  var formRedirect = $(this).attr("redirect");

  var formData = $(this).serialize();

  $.ajax({
    type: formMethod,
    url: formAction,
    data: formData,
    dataType: "json",
    success: function (response) {
      if (response.message) {
        Snackbar.show({
          text: response.message,
          pos: "bottom-right",
          backgroundColor: "#181c2b",
          actionTextColor: "#ff5a3d",
        });
        setTimeout(() => {
          window.location.href = formRedirect;
        }, 1000);
      } else if (response.error) {
        Snackbar.show({
          text: response.error,
          pos: "bottom-right",
          backgroundColor: "#EA5151",
          actionTextColor: "#fff",
        });
      }
    },
  });
}
