<?php
include('dbconfig.php');
$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM accounts WHERE email = ? AND password = ?";


$stmt = $sqlConn->prepare($sql);

$stmt->bind_param("ss", $email, $password);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $account = $result->fetch_assoc();
    $_SESSION['account'] = $account['name'];
    echo json_encode(['message' => "User logged in"]);
} else {
    echo json_encode(['error' => "User not found"]);
}

$stmt->close();
$sqlConn->close();
