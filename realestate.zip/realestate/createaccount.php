<?php
include('dbconfig.php');

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];
$phone = $_POST['phonenumber'];
$zipCode = $_POST['zipcode'];
$country = $_POST['country'];
$city = $_POST['city'];
$state = $_POST['state'];

$sql = "INSERT INTO accounts (name, email, password, phone, zip_code, country, city, state)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";


$stmt = $sqlConn->prepare($sql);


$stmt->bind_param("ssssssss", $name, $email, $password, $phone, $zipCode, $country, $city, $state);

$result = $stmt->execute();

if ($result) {
    $_SESSION['account'] = $name;
    echo json_encode(['message' => "User created successfully!"]);
} else {
    echo json_encode(['error' => $stmt->error]);
}


$stmt->close();
$sqlConn->close();
