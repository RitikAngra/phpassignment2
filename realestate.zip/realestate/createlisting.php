<?php
include("websiteheader.php");
?>
<div class="form">
    <h2 class="h2 section-title"><?= isset($_GET['listingid']) ? 'Edit' : 'Add' ?> Listing</h2>
    <p class="section-description text-center"><?= isset($_GET['listingid']) ? 'Edit' : 'Add a new' ?> listing if you want to rent or sell your home or apartment</p>
    <form redirect="index.php" id="createlisting-form" action="storelisting.php" method="POST" class="contact-form-grid" enctype="multipart/form-data">
        <div><label class="field-label">Price</label>
            <input type="number" class="text-field w-input" name="price" placeholder="2000" required>
        </div>
        <div><label class="field-label">Category</label>
            <select name="category" class="text-field w-input">
                <option value="House">House</option>
                <option value="Apartment">Apartment</option>
            </select>
        </div>
        <div><label class="field-label">Location</label>
            <input type="text" class="text-field w-input" name="location" placeholder="12th Avenue St" required>
        </div>
        <div><label class="field-label">Number of beds</label>
            <input type="number" class="text-field w-input" name="beds" placeholder="12" required>
        </div>
        <div><label class="field-label">Number of bathrooms</label>
            <input type="number" class="text-field w-input" name="bathrooms" placeholder="2" required>
        </div>
        <div><label class="field-label">Number of rooms</label>
            <input type="number" class="text-field w-input" name="rooms" placeholder="10" required>
        </div>
        <div><label class="field-label">Type</label>
            <select name="type" class="text-field w-input">
                <option value="Rent">Rent</option>
                <option value="Sell">Sell</option>
            </select>
        </div>
        <div><label class="field-label">Image</label>
            <input type="file" class="text-field w-input" name="listingimage" required>
        </div>
        <div class="w-100 centered"><input type="submit" value="Submit" class="button w-button"></div>
    </form>
</div>
<?php
include("websitefooter.html");
if (isset($_GET['success'])) {
?>
    <script>
        Snackbar.show({
            text: "<?= $_GET['success'] ?>",
            pos: "bottom-right",
            backgroundColor: "#181c2b",
            actionTextColor: "#ff5a3d",
        });
        setTimeout(() => {
            window.location.href = 'index.php';
        }, 1000);
    </script>
<?php
}
?>