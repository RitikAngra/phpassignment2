<?php
include("websiteheader.php");
?>
<div class="form">
    <h2 class="h2 section-title">Register</h2>
    <p class="section-description text-center">Create an account to update or delete listings.</p>
    <form redirect="index.php" id=" createuser-form" action="createaccount.php" method="POST" class="contact-form-grid">
        <div><label class="field-label">Name</label><input type="text" class="text-field w-input" name="name" placeholder="Lorem Ipsumsson" required></div>
        <div><label class="field-label">Phone number</label><input type="text" class="text-field w-input" name="phonenumber" placeholder="+1234123456" required></div>
        <?php
        include('country.html');
        ?>
        <div><label class="field-label">State</label><input type="text" class="text-field w-input" name="state" placeholder="New York" required></div>
        <div><label class="field-label">City</label><input type="text" class="text-field w-input" name="city" placeholder="New York" required></div>
        <div><label class="field-label">Zip Code</label><input type="text" class="text-field w-input" name="zipcode" placeholder="10080" required></div>
        <div><label class="field-label">Email</label><input type="email" class="text-field w-input" name="email" placeholder="example@realestate.com" required></div>
        <div><label class="field-label">Password</label><input type="password" class="text-field w-input" name="password" placeholder="*******" required></div>
        <div class="w-100 centered"><input type="submit" value="Submit" class="button w-button"></div>
    </form>
</div>
<?php
include("websitefooter.html");
?>