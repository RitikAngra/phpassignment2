<?php
session_start();
$sqlConn = new mysqli("localhost", "admin", "H_C[9FYPAMLkVDIm", "realestate");
