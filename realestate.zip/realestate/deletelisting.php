<?php
include('dbconfig.php');
$listingid = $_POST['listingid'];


$sql = "DELETE FROM listings WHERE listing_id = ?";

$stmt = $sqlConn->prepare($sql);

$stmt->bind_param("i", $listingid);


$result = $stmt->execute();


if ($result) {
    header("Location:listing.php?delete_success=1");
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$sqlConn->close();
