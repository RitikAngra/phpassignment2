<?php
include('dbconfig.php');

$listingId = isset($_GET['listingId']) ? $_GET['listingId'] : '';

if ($listingId) {
    $sql = "SELECT * FROM listings WHERE listing_id = '$listingId'";
} else {
    $sql = "SELECT * FROM listings";
}



$result = $sqlConn->query($sql);


if ($result->num_rows > 0) {
    $listings = $result->fetch_all(MYSQLI_ASSOC);

    $result->close();

    $sqlConn->close();

    $res = ["listings" => $listings];

    if (isset($_SESSION['account'])) {
        $res['loggedIn'] = true;
    }

    if ($listingId) {
        echo json_encode($listings[0]);
    } else {
        echo json_encode($res);
    }
} else {
    $sqlConn->close();
    echo json_encode(array());
}
