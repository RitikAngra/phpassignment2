<?php
include("websiteheader.php");
?>

<div class="hero-wrap">
    <div class="hero-content-wrap"><img src="./assets/images/logo.png" loading="lazy" alt="" class="hero-image">
        <div class="hero-title">Find Your Dream House By Us</div>
    </div><a href="#listing" class="animated-arrow-wrap"><img src="./assets/icons/down-arrow.svg" loading="lazy" alt="" class="animated-arrow-icon"></a>
    <div class="hero-hello-text">Welcome home.</div>
    <div class="hero-background-image-wrap">
        <div class="hero-background-overlay"></div>
    </div>
</div>

<div class="section bg-neutral-5" id="listing">
    <div class="container">
        <p class="section-subtitle">Properties</p>
        <div class="section-title reveal">
            <h3 class="text-section-title text-primary">What we have in store for you.</h3>
        </div>
        <div class="w-dyn-list">
            <div class="listings-grid w-dyn-items" id="listing-grid">
                <?php
                for ($i = 0; $i < 3; $i++) {
                ?>
                    <div class="card loading">
                        <div class="image">
                        </div>
                        <div class="content">
                            <h4></h4>
                            <div class="group">
                                <h4></h4>
                                <h4></h4>
                                <h4></h4>
                            </div>
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>
        <div class="view-all-button-wrap reveal">
            <a href="listing.php" class="button-wrap">
                <div class="button-text">Show all listings</div><img src="./assets/icons/arrow.svg" loading="lazy" alt="" class="button-arrow-icon">
            </a>
        </div>
    </div>
</div>

<?php
include("websitefooter.html");
?>