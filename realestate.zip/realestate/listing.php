<?php
include("websiteheader.php");
?>
<div class="section bg-neutral-5" id="listing">
    <div class="container">
        <p class="section-subtitle">Properties</p>
        <div class="section-title reveal">
            <h3 class="text-section-title text-primary">What we have in store for you.</h3>
        </div>
        <div class="w-dyn-list">
            <div class="listings-grid w-dyn-items" id="listing-grid">
                <?php
                for ($i = 0; $i < 10; $i++) {
                ?>
                    <div class="card loading">
                        <div class="image">
                        </div>
                        <div class="content">
                            <h4></h4>
                            <div class="group">
                                <h4></h4>
                                <h4></h4>
                                <h4></h4>
                            </div>
                        </div>
                    </div>
                <?php
                }
                ?>
            </div>
        </div>

    </div>
</div>

<?php
include("websitefooter.html");
if (isset($_GET['delete_success'])) {
?>
    <script>
        Snackbar.show({
            text: 'Listing deleted successfully',
            pos: "bottom-right",
            backgroundColor: "#181c2b",
            actionTextColor: "#ff5a3d",
        });
        setTimeout(() => {
            window.location.href = 'listing.php';
        }, 1000);
    </script>
<?php
}
?>