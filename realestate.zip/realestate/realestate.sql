-- Database: realestate
-- Query for creating accounts table

CREATE TABLE `accounts` (
  `account_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `zip_code` varchar(10) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Query for inserting data into accounts table

INSERT INTO `accounts` (`account_id`, `name`, `email`, `password`, `phone`, `zip_code`, `country`, `city`, `state`) VALUES
(1, 'Micheal Smith', 'michealsmith@realstate.com', 'Pa$$w0rd!', '+1 (369) 745-6818', '32742', 'United States', 'California', 'California');

-- --------------------------------------------------------


-- Query for creating listings table

CREATE TABLE `listings` (
  `listing_id` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `beds` int(11) DEFAULT NULL,
  `bathrooms` int(11) DEFAULT NULL,
  `rooms` int(11) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `listing_image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- Query for inserting data into listings table

INSERT INTO `listings` (`listing_id`, `price`, `category`, `location`, `beds`, `bathrooms`, `rooms`, `type`, `listing_image`) VALUES
(1, '410.00', 'Apartment', 'Park Avenue', 10, 8, 8, 'Rent', 'assets/listingimages/listing2.jpg');


-- Alter accounts table to make account_id as primary key and set unique constraint on email column

ALTER TABLE `accounts`
  ADD PRIMARY KEY (`account_id`),
  ADD UNIQUE KEY `email` (`email`);

-- Alter listings table to make listing_id as primary key

ALTER TABLE `listings`
  ADD PRIMARY KEY (`listing_id`);



-- Alter accounts table to make account_id auto increment

ALTER TABLE `accounts`
  MODIFY `account_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;


-- Alter listings table to make listing_id auto increment

ALTER TABLE `listings`
  MODIFY `listing_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

