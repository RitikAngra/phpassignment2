<?php
include('dbconfig.php');

$listing_id = isset($_POST['listing_id']) ? $_POST['listing_id'] : '';
$price = $_POST['price'];
$category = $_POST['category'];
$location = $_POST['location'];
$beds = $_POST['beds'];
$bathrooms = $_POST['bathrooms'];
$rooms = $_POST['rooms'];
$type = $_POST['type'];

$targetDirectory = "assets/listingimages/";
$targetFile = $targetDirectory . basename($_FILES["listingimage"]["name"]);

if (!is_dir($targetDirectory)) {
    mkdir($targetDirectory);
}

move_uploaded_file($_FILES["listingimage"]["tmp_name"], $targetFile);

if ($listing_id) {
    $sql = "UPDATE listings
            SET price = ?, category = ?, location = ?, beds = ?, bathrooms = ?, rooms = ?, type = ?, listing_image = ?
            WHERE listing_id = ?";
    $stmt = $sqlConn->prepare($sql);
    $stmt->bind_param("sssdssssi", $price, $category, $location, $beds, $bathrooms, $rooms, $type, $targetFile, $listing_id);
} else {
    $sql = "INSERT INTO listings (price, category, location, beds, bathrooms, rooms, type, listing_image)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $sqlConn->prepare($sql);
    $stmt->bind_param("sssdssss", $price, $category, $location, $beds, $bathrooms, $rooms, $type, $targetFile);
}

$result = $stmt->execute();

if ($result) {
    $m = $listing_id ? "Listing updated successfully" : "Listing inserted successfully";
    header("Location: createlisting.php?success=$m");
}

$stmt->close();
$sqlConn->close();
