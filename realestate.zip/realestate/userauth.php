<?php
include("websiteheader.php");
?>
<div class="form">
    <h2 class="h2 section-title">Sign In</h2>
    <p class="section-description text-center">Sign in to your account to update or delete listings.</p>
    <form redirect="index.php" id=" authenticateuser-form" action="authenticateuser.php" method="POST" class="contact-form-grid">
        <div><label class="field-label">Email</label><input type="email" class="text-field w-input" name="email" placeholder="example@realestate.com" required></div>
        <div><label class="field-label">Password</label><input type="password" class="text-field w-input" name="password" placeholder="*******" required></div>
        <div class="w-100 centered"><input type="submit" value="Submit" class="button w-button"></div>
    </form>
</div>
<?php
include("websitefooter.html");
?>