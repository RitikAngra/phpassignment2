<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Real Estate</title>
  <link rel="stylesheet" href="./assets/css/style.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link rel="stylesheet" href="assets/css/snackbar.min.css" />
  <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet" />
</head>

<body>
  <header class="header" data-header>
    <div class="header-top">
      <div class="container">
        <div class="wrapper">
          <a href="createlisting.php"><button class="header-top-btn">Add Listing</button></a>
          <?php
          if (!isset($_SESSION['account'])) {
          ?>
            <a href="createuser.php">
              <button class="header-top-btn">Register</button></a>
            <a href="userauth.php">
              <button class="header-top-btn">Sign in</button></a>
          <?php
          } else {
          ?>
            <a href="logout.php"><button class="header-top-btn">Logout</button></a>
          <?php
          }
          ?>
        </div>
      </div>
    </div>
    <div class="navigation">
      <div class="sticky-nav nav">
        <div class="nav-container">
          <a href="index.php" class="brand nav-brand"><img src="./assets/images/logo.png" loading="lazy" alt="" class="nav-logotype" /></a>
          <nav role="navigation" class="nav-menu nav-menu">
            <div class="nav-link-list-item">
              <a href="listing.php" aria-current="page" class="nav-link nav-link">Listings</a>
            </div>
          </nav>
        </div>
        <div class="nav-overlay"></div>
      </div>
    </div>
  </header>
</body>

</html>